from setuptools import setup, find_packages

setup(name="pharmaimage", packages=find_packages())
